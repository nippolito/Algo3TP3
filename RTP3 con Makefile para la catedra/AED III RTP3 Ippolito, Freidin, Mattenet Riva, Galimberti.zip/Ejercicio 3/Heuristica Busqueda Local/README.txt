Los parametros que se le deben pasar a la busqueda local son:
1° n = tamaño del grafo
2° m = cantidad de aristas (nodos incluidos en [1...n])
3° m lineas describiendo las conexiones dentro del grafo
4° SoluciónSemillaSize = Tamaño de solución Semilla
5° SoluciónSemillaSize lineas diciendo qué nodos pertenecen a la misma
